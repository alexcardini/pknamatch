import PDFDocument from 'pdfkit';
import { Customer, DuplicateGroup } from '../shared/schema';
import fs from 'fs';
import path from 'path';

interface MergeReportData {
  mergeDate: Date;
  mergedGroups: {
    groupId: string;
    primaryRecord: Customer;
    mergedRecords: Customer[];
    matchReason?: string;
  }[];
  totalMerges: number;
  fileName?: string;
}

export function generateMergeReport(data: MergeReportData): string {
  const doc = new PDFDocument({ margin: 50 });
  
  // Setup file path
  const reportDir = path.resolve('./uploads/reports');
  
  // Create directory if it doesn't exist
  if (!fs.existsSync(reportDir)) {
    fs.mkdirSync(reportDir, { recursive: true });
  }
  
  // Generate a filename if not provided
  const fileName = data.fileName || 
    `merge-report-${new Date().toISOString().replace(/[:.]/g, '-')}.pdf`;
  
  const filePath = path.join(reportDir, fileName);
  const writeStream = fs.createWriteStream(filePath);
  
  doc.pipe(writeStream);
  
  // Add report header
  doc.fontSize(25)
    .text('Customer Data Merge Report', { align: 'center' })
    .moveDown();
  
  doc.fontSize(12)
    .text(`Generated on: ${data.mergeDate.toLocaleString()}`, { align: 'left' })
    .text(`Total Merges: ${data.totalMerges}`)
    .moveDown()
    .moveDown();
  
  // Add merge details
  doc.fontSize(18)
    .text('Merge Details', { align: 'left' })
    .moveDown();
  
  data.mergedGroups.forEach((group, groupIndex) => {
    // Group header
    doc.fontSize(14)
      .fillColor('#2C5282')
      .text(`Group ${groupIndex + 1}: ${group.primaryRecord.firstName} ${group.primaryRecord.lastName}`, { underline: true })
      .fillColor('black')
      .moveDown(0.5);
    
    // Match reason if available
    if (group.matchReason) {
      doc.fontSize(10)
        .fillColor('#666666')
        .text(`Match Reason: ${group.matchReason}`)
        .fillColor('black')
        .moveDown(0.5);
    }
    
    // Primary record details
    doc.fontSize(12)
      .text('Primary Record:', { continued: true })
      .fontSize(10)
      .text(` ID: ${group.primaryRecord.customerId}`)
      .text(`Name: ${group.primaryRecord.firstName} ${group.primaryRecord.lastName}`)
      .text(`Phone: ${group.primaryRecord.phone}`)
      .text(`Address: ${group.primaryRecord.address}`)
      .text(`Zone: ${group.primaryRecord.zone || 'N/A'}`)
      .moveDown();
    
    // Merged records
    if (group.mergedRecords.length > 0) {
      doc.fontSize(12)
        .text(`Merged Records (${group.mergedRecords.length}):`)
        .moveDown(0.5);
      
      group.mergedRecords.forEach((record, index) => {
        doc.fontSize(10)
          .text(`${index + 1}. ID: ${record.customerId}`)
          .text(`   Name: ${record.firstName} ${record.lastName}`)
          .text(`   Phone: ${record.phone}`)
          .text(`   Address: ${record.address}`)
          .text(`   Zone: ${record.zone || 'N/A'}`)
          .moveDown(0.5);
      });
    }
    
    // Add separator between groups
    if (groupIndex < data.mergedGroups.length - 1) {
      doc.moveDown()
        .strokeColor('#cccccc')
        .lineWidth(1)
        .moveTo(50, doc.y)
        .lineTo(doc.page.width - 50, doc.y)
        .stroke()
        .moveDown();
    }
  });
  
  // Summary at the end
  doc.addPage()
    .fontSize(18)
    .text('Merge Summary', { align: 'center' })
    .moveDown();
  
  doc.fontSize(12)
    .text(`Total merge groups: ${data.mergedGroups.length}`)
    .text(`Total records merged: ${data.mergedGroups.reduce((sum, group) => sum + group.mergedRecords.length, 0)}`)
    .text(`Primary records kept: ${data.mergedGroups.length}`);
  
  // Finalize the PDF
  doc.end();
  
  return filePath;
}

// Function to generate CSV of merged data
export function generateMergedCsv(customers: Customer[]): string {
  const csvHeader = 'Customer ID,First Name,Last Name,Phone,Address,Zone,Total Spent,Last Order Date,Status,Is Merged,Merged From\n';
  
  // No need to filter here - we expect already filtered data from routes.ts
  console.log(`CSV generation with ${customers.length} pre-filtered customer records`);
  
  const csvRows = customers.map(customer => {
    const mergedFrom = customer.mergedFrom ? `"${customer.mergedFrom.join(', ')}"` : '';
    const totalSpent = customer.totalSpent || '0.00';
    const lastOrderDate = customer.lastOrderDate ? new Date(customer.lastOrderDate).toLocaleDateString() : '';
    
    return [
      customer.customerId,
      `"${customer.firstName}"`,
      `"${customer.lastName}"`,
      `"${customer.phone}"`,
      `"${customer.address}"`,
      `"${customer.zone || ''}"`,
      totalSpent,
      `"${lastOrderDate}"`,
      `"${customer.status || 'clean'}"`,
      customer.isMerged ? 'Yes' : 'No',
      mergedFrom
    ].join(',');
  });
  
  const csvContent = csvHeader + csvRows.join('\n');
  
  // Save the CSV file
  const csvDir = path.resolve('./uploads/csv');
  
  // Create directory if it doesn't exist
  if (!fs.existsSync(csvDir)) {
    fs.mkdirSync(csvDir, { recursive: true });
  }
  
  const fileName = `merged-customers-${new Date().toISOString().replace(/[:.]/g, '-')}.csv`;
  const filePath = path.join(csvDir, fileName);
  
  fs.writeFileSync(filePath, csvContent);
  
  console.log(`CSV generated with ${customers.length} customer records`);
  
  return filePath;
}