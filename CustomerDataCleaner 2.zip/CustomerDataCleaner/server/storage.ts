import { v4 as uuidv4 } from 'uuid';
import { 
  customers, type Customer, type InsertCustomer, type UpdateCustomer,
  fileHistory, type FileHistory, type InsertFileHistory
} from "@shared/schema";

// Interface for the storage service
export interface IStorage {
  // Customer operations
  getCustomers(): Promise<Customer[]>;
  getCustomer(id: number): Promise<Customer | undefined>;
  getCustomerByCustomerId(customerId: string): Promise<Customer | undefined>;
  createCustomer(customer: InsertCustomer): Promise<Customer>;
  updateCustomer(id: number, customer: UpdateCustomer): Promise<Customer | undefined>;
  deleteCustomer(id: number): Promise<boolean>;
  searchCustomers(term: string): Promise<Customer[]>;
  
  // File history operations
  getFileHistories(): Promise<FileHistory[]>;
  getFileHistory(id: number): Promise<FileHistory | undefined>;
  createFileHistory(fileHistory: InsertFileHistory): Promise<FileHistory>;
  
  // Bulk operations
  bulkCreateCustomers(customers: InsertCustomer[]): Promise<Customer[]>;
  bulkUpdateCustomers(customers: { id: number; customer: UpdateCustomer }[]): Promise<Customer[]>;
  
  // Data analytics
  countCustomers(): Promise<number>;
  countDuplicates(): Promise<number>;
  
  // Data management
  clearAllData(): Promise<void>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private customersData: Map<number, Customer>;
  private fileHistoriesData: Map<number, FileHistory>;
  private currentCustomerId: number;
  private currentFileHistoryId: number;

  constructor() {
    this.customersData = new Map();
    this.fileHistoriesData = new Map();
    this.currentCustomerId = 1;
    this.currentFileHistoryId = 1;
  }

  // Customer operations
  async getCustomers(): Promise<Customer[]> {
    return Array.from(this.customersData.values());
  }

  async getCustomer(id: number): Promise<Customer | undefined> {
    return this.customersData.get(id);
  }

  async getCustomerByCustomerId(customerId: string): Promise<Customer | undefined> {
    return Array.from(this.customersData.values()).find(
      (customer) => customer.customerId === customerId
    );
  }

  async createCustomer(insertCustomer: InsertCustomer): Promise<Customer> {
    const id = this.currentCustomerId++;
    const customer: Customer = { 
      ...insertCustomer, 
      id,
      customerId: insertCustomer.customerId || `CU-${10000 + id}`,
      createdAt: new Date()
    };
    this.customersData.set(id, customer);
    return customer;
  }

  async updateCustomer(id: number, updateCustomer: UpdateCustomer): Promise<Customer | undefined> {
    const existingCustomer = this.customersData.get(id);
    if (!existingCustomer) return undefined;

    const updatedCustomer: Customer = {
      ...existingCustomer,
      ...updateCustomer,
    };
    this.customersData.set(id, updatedCustomer);
    return updatedCustomer;
  }

  async deleteCustomer(id: number): Promise<boolean> {
    return this.customersData.delete(id);
  }

  async searchCustomers(term: string): Promise<Customer[]> {
    const lowercaseTerm = term.toLowerCase();
    return Array.from(this.customersData.values()).filter(customer => 
      customer.firstName.toLowerCase().includes(lowercaseTerm) ||
      customer.lastName.toLowerCase().includes(lowercaseTerm) ||
      customer.phone.includes(term) ||
      customer.address.toLowerCase().includes(lowercaseTerm) ||
      (customer.zone && customer.zone.toLowerCase().includes(lowercaseTerm))
    );
  }

  // File history operations
  async getFileHistories(): Promise<FileHistory[]> {
    return Array.from(this.fileHistoriesData.values())
      .sort((a, b) => b.processedAt.getTime() - a.processedAt.getTime());
  }

  async getFileHistory(id: number): Promise<FileHistory | undefined> {
    return this.fileHistoriesData.get(id);
  }

  async createFileHistory(insertFileHistory: InsertFileHistory): Promise<FileHistory> {
    const id = this.currentFileHistoryId++;
    const fileHistory: FileHistory = {
      ...insertFileHistory,
      id,
      processedAt: new Date()
    };
    this.fileHistoriesData.set(id, fileHistory);
    return fileHistory;
  }

  // Bulk operations
  async bulkCreateCustomers(customersToCreate: InsertCustomer[]): Promise<Customer[]> {
    const createdCustomers: Customer[] = [];
    
    for (const customerData of customersToCreate) {
      const customer = await this.createCustomer(customerData);
      createdCustomers.push(customer);
    }
    
    return createdCustomers;
  }

  async bulkUpdateCustomers(customersToUpdate: { id: number; customer: UpdateCustomer }[]): Promise<Customer[]> {
    const updatedCustomers: Customer[] = [];
    
    for (const { id, customer } of customersToUpdate) {
      const updatedCustomer = await this.updateCustomer(id, customer);
      if (updatedCustomer) {
        updatedCustomers.push(updatedCustomer);
      }
    }
    
    return updatedCustomers;
  }

  // Data analytics
  async countCustomers(): Promise<number> {
    return this.customersData.size;
  }

  async countDuplicates(): Promise<number> {
    return Array.from(this.customersData.values()).filter(
      customer => customer.isMerged
    ).length;
  }
  
  // Data management
  async clearAllData(): Promise<void> {
    // Clear all customer data
    this.customersData.clear();
    this.currentCustomerId = 1;
    
    // Clear all file history data
    this.fileHistoriesData.clear();
    this.currentFileHistoryId = 1;
    
    console.log("All data cleared successfully");
  }
}

export const storage = new MemStorage();
