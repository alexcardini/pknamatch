import { Link, useLocation } from "wouter";
import { Home, Users, ShoppingBag, FileText, Settings } from "lucide-react";

export default function Sidebar() {
  const [location] = useLocation();

  const isActive = (path: string) => {
    return location === path;
  };

  const menuItems = [
    { icon: Home, label: "Dashboard", path: "/" },
    { icon: Users, label: "Customers", path: "/customers" },
    { icon: ShoppingBag, label: "Orders", path: "/orders" },
    { icon: FileText, label: "Reports", path: "/reports" },
    { icon: Settings, label: "Settings", path: "/settings" },
  ];

  return (
    <>
      <div className="flex items-center justify-center h-16 px-4 border-b border-blue-800">
        <h1 className="text-xl font-bold">DataUnify</h1>
      </div>
      <nav className="flex-1 pt-4 pb-4">
        <ul>
          {menuItems.map((item) => (
            <li key={item.path}>
              <Link href={item.path}>
                <a
                  className={`flex items-center px-6 py-3 text-white ${
                    isActive(item.path) ? "bg-blue-800" : "hover:bg-blue-800"
                  }`}
                >
                  <span className="inline-block w-5 h-5 mr-3">
                    <item.icon className="h-5 w-5" />
                  </span>
                  {item.label}
                </a>
              </Link>
            </li>
          ))}
        </ul>
      </nav>
      <div className="px-6 py-4">
        <div className="flex items-center">
          <div className="w-8 h-8 rounded-full bg-blue-800 flex items-center justify-center text-sm font-semibold">
            JD
          </div>
          <div className="ml-3">
            <p className="text-sm font-medium">John Doe</p>
            <p className="text-xs opacity-75">Administrator</p>
          </div>
        </div>
      </div>
    </>
  );
}
