import { FileText } from "lucide-react";
import { FileHistory } from "@/lib/types";

interface RecentFilesListProps {
  files: FileHistory[];
}

export default function RecentFilesList({ files }: RecentFilesListProps) {
  const formatDate = (date: Date): string => {
    const now = new Date();
    const fileDate = new Date(date);
    
    if (fileDate.toDateString() === now.toDateString()) {
      return `Today, ${fileDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    } else if (
      fileDate.toDateString() === 
      new Date(now.setDate(now.getDate() - 1)).toDateString()
    ) {
      return `Yesterday, ${fileDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    } else {
      return fileDate.toLocaleDateString([], { month: 'short', day: 'numeric' }) + 
        `, ${fileDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    }
  };

  // If no files, show empty state
  if (!files || files.length === 0) {
    return (
      <div className="text-sm text-gray-600">
        <p>No files have been processed yet.</p>
      </div>
    );
  }

  return (
    <div className="text-sm text-gray-600">
      {files.slice(0, 5).map((file, index) => (
        <div key={file.id || index} className="flex items-center py-2 border-b">
          <FileText className="h-4 w-4 text-[#2C5282] mr-2" />
          <span>{file.filename}</span>
          <span className="ml-auto text-xs text-gray-500">
            {formatDate(new Date(file.processedAt))}
          </span>
        </div>
      ))}
    </div>
  );
}
