import { CheckCircle, Circle, Info } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

interface ProcessingStageProps {
  icon: React.ReactNode;
  label: string;
  status: "completed" | "in-progress" | "pending";
  progress: number;
}

function ProcessingStage({ icon, label, status, progress }: ProcessingStageProps) {
  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center">
          {icon}
          <span>{label}</span>
        </div>
        <span className="text-sm">
          {status === "completed"
            ? "Completed"
            : status === "in-progress"
            ? `In Progress (${progress}%)`
            : "Pending"}
        </span>
      </div>
      <Progress value={progress} className="h-2" />
    </div>
  );
}

interface ProcessingStatusProps {
  stage: string;
  progress: number;
  totalRecords: number;
  potentialDuplicates: number;
}

export default function ProcessingStatus({
  stage,
  progress,
  totalRecords,
  potentialDuplicates,
}: ProcessingStatusProps) {
  const getStageProgress = (stageName: string): number => {
    const stages = ["validation", "fuzzyMatching", "recordMerging", "idAssignment", "databaseUpdate"];
    const currentStageIndex = stages.indexOf(stage);
    const targetStageIndex = stages.indexOf(stageName);

    if (targetStageIndex < currentStageIndex) return 100;
    if (targetStageIndex > currentStageIndex) return 0;
    return progress;
  };

  const getStageStatus = (stageName: string): "completed" | "in-progress" | "pending" => {
    const stages = ["validation", "fuzzyMatching", "recordMerging", "idAssignment", "databaseUpdate"];
    const currentStageIndex = stages.indexOf(stage);
    const targetStageIndex = stages.indexOf(stageName);

    if (targetStageIndex < currentStageIndex) return "completed";
    if (targetStageIndex > currentStageIndex) return "pending";
    return "in-progress";
  };

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">Processing Status</h2>
          <span className="px-3 py-1 bg-blue-100 text-[#2C5282] rounded-full text-sm font-medium">
            In Progress
          </span>
        </div>

        <div className="space-y-6">
          <ProcessingStage
            icon={
              <CheckCircle
                className={`h-5 w-5 ${
                  getStageStatus("validation") === "completed" ? "text-[#48BB78]" : "text-gray-400"
                } mr-2`}
              />
            }
            label="Data Validation"
            status={getStageStatus("validation")}
            progress={getStageProgress("validation")}
          />

          <ProcessingStage
            icon={
              <CheckCircle
                className={`h-5 w-5 ${
                  getStageStatus("fuzzyMatching") === "completed" ? "text-[#48BB78]" : "text-gray-400"
                } mr-2`}
              />
            }
            label="Fuzzy Matching"
            status={getStageStatus("fuzzyMatching")}
            progress={getStageProgress("fuzzyMatching")}
          />

          <ProcessingStage
            icon={
              <Circle
                className={`h-5 w-5 ${
                  getStageStatus("recordMerging") === "completed"
                    ? "text-[#48BB78]"
                    : getStageStatus("recordMerging") === "in-progress"
                    ? "text-[#2C5282]"
                    : "text-gray-400"
                } mr-2`}
              />
            }
            label="Record Merging"
            status={getStageStatus("recordMerging")}
            progress={getStageProgress("recordMerging")}
          />

          <ProcessingStage
            icon={
              <Circle
                className={`h-5 w-5 ${
                  getStageStatus("idAssignment") === "completed"
                    ? "text-[#48BB78]"
                    : getStageStatus("idAssignment") === "in-progress"
                    ? "text-[#2C5282]"
                    : "text-gray-400"
                } mr-2`}
              />
            }
            label="ID Assignment"
            status={getStageStatus("idAssignment")}
            progress={getStageProgress("idAssignment")}
          />

          <ProcessingStage
            icon={
              <Circle
                className={`h-5 w-5 ${
                  getStageStatus("databaseUpdate") === "completed"
                    ? "text-[#48BB78]"
                    : getStageStatus("databaseUpdate") === "in-progress"
                    ? "text-[#2C5282]"
                    : "text-gray-400"
                } mr-2`}
              />
            }
            label="Database Update"
            status={getStageStatus("databaseUpdate")}
            progress={getStageProgress("databaseUpdate")}
          />
        </div>

        <div className="mt-6">
          <div className="flex items-center">
            <div className="bg-blue-100 text-[#2C5282] p-3 rounded-full">
              <Info className="h-6 w-6" />
            </div>
            <div className="ml-4">
              <h3 className="text-sm font-medium">Processing Information</h3>
              <p className="text-sm text-gray-500">
                {totalRecords > 0
                  ? `Found ${totalRecords} total records. Identified ${potentialDuplicates} potential duplicates.`
                  : "Processing your data. This may take a moment..."}
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
