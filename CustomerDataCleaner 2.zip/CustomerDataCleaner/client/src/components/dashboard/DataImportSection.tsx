import { useState, useRef } from "react";
import { Upload, CheckCircle, Trash2, AlertCircle } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { FileHistory } from "@/lib/types";
import { queryClient } from "@/lib/queryClient";
import RecentFilesList from "./RecentFilesList";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface DataImportSectionProps {
  onFileUploaded: () => void;
  recentFiles: FileHistory[];
}

export default function DataImportSection({ onFileUploaded, recentFiles }: DataImportSectionProps) {
  const [file, setFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const selectedFile = e.target.files[0];
      validateAndSetFile(selectedFile);
    }
  };

  const validateAndSetFile = (selectedFile: File) => {
    // Validate file type
    if (!selectedFile.name.toLowerCase().endsWith('.csv')) {
      toast({
        title: "Invalid file type",
        description: "Please upload a CSV file.",
        variant: "destructive",
      });
      return;
    }

    // Validate file size (10MB max)
    if (selectedFile.size > 10 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "The file size should not exceed 10MB.",
        variant: "destructive",
      });
      return;
    }

    setFile(selectedFile);
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      validateAndSetFile(e.dataTransfer.files[0]);
    }
  };

  const handleUpload = async () => {
    if (!file) {
      toast({
        title: "No file selected",
        description: "Please select a file to upload.",
        variant: "destructive",
      });
      return;
    }

    setIsUploading(true);

    try {
      const formData = new FormData();
      formData.append("file", file);

      const response = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error(`Upload failed: ${response.statusText}`);
      }

      const data = await response.json();
      
      toast({
        title: "Upload successful",
        description: `${data.recordCount} records processed successfully.`,
      });
      
      setFile(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
      
      // Notify parent component
      onFileUploaded();
    } catch (error) {
      console.error("Upload error:", error);
      toast({
        title: "Upload failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };
  
  const handleClearAllData = async () => {
    setIsDeleting(true);
    
    try {
      // Use fetch directly since apiRequest expects different parameters
      const response = await fetch("/api/clear-all-data", {
        method: "DELETE"
      });
      
      if (!response.ok) {
        throw new Error(`Failed to clear data: ${response.statusText}`);
      }
      
      toast({
        title: "Data cleared",
        description: "All customer data and file history has been deleted.",
        variant: "default",
      });
      
      // Invalidate queries to refresh UI
      queryClient.invalidateQueries({ queryKey: ['/api/customers'] });
      queryClient.invalidateQueries({ queryKey: ['/api/file-history'] });
      queryClient.invalidateQueries({ queryKey: ['/api/analytics'] });
      queryClient.invalidateQueries({ queryKey: ['/api/find-duplicates'] });
      
      // Notify parent component
      onFileUploaded();
    } catch (error) {
      console.error("Clear data error:", error);
      toast({
        title: "Failed to clear data",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    } finally {
      setIsDeleting(false);
      setShowDeleteConfirm(false);
    }
  };

  return (
    <>
      <Card>
        <CardContent className="p-6">
          <h2 className="text-xl font-semibold mb-4">Import Customer Data</h2>
          <p className="mb-4 text-gray-600">Upload a CSV file to begin the deduplication and data cleaning process.</p>
          
          <div className="flex flex-col md:flex-row gap-6">
            <div 
              className={`md:w-1/2 border-2 border-dashed rounded-lg p-6 text-center bg-gray-50 cursor-pointer ${
                isDragging ? "border-[#2C5282] bg-blue-50" : "border-gray-300"
              }`}
              onClick={() => fileInputRef.current?.click()}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <input
                type="file"
                className="hidden"
                accept=".csv"
                onChange={handleFileChange}
                ref={fileInputRef}
              />
              
              {file ? (
                <>
                  <CheckCircle className="h-12 w-12 mx-auto text-[#48BB78] mb-4" />
                  <span className="mt-2 text-base font-medium text-gray-900">
                    Selected: {file.name} ({(file.size / 1024 / 1024).toFixed(2)} MB)
                  </span>
                  <p className="text-xs text-gray-500 mt-2">Click to change file</p>
                </>
              ) : (
                <>
                  <Upload className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                  <span className="mt-2 text-base font-medium text-gray-900">
                    Drag and drop your file here, or <span className="text-[#2C5282] font-medium">browse</span>
                  </span>
                  <p className="text-xs text-gray-500 mt-2">CSV files only, max size 10MB</p>
                </>
              )}
            </div>
            
            <div className="md:w-1/2">
              <h3 className="font-semibold mb-2">File Requirements</h3>
              <ul className="text-sm text-gray-600 space-y-2">
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-[#48BB78] mr-2 flex-shrink-0" />
                  Must contain customer name fields (first name, last name)
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-[#48BB78] mr-2 flex-shrink-0" />
                  Should include contact information (phone, address)
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-[#48BB78] mr-2 flex-shrink-0" />
                  UTF-8 encoding is recommended
                </li>
              </ul>
              
              <div className="mt-6">
                <h3 className="font-semibold mb-2">Recently Processed Files</h3>
                <RecentFilesList files={recentFiles} />
              </div>
            </div>
          </div>

          <div className="flex justify-between items-center mt-6">
            <Button
              variant="outline"
              size="sm"
              className="flex items-center text-red-600 hover:text-red-700 hover:bg-red-50"
              onClick={() => setShowDeleteConfirm(true)}
              disabled={isDeleting}
            >
              <Trash2 className="mr-2 h-4 w-4" />
              {isDeleting ? "Deleting..." : "Delete All Data"}
            </Button>
            
            <Button 
              onClick={handleUpload} 
              disabled={!file || isUploading}
              className="px-4 py-2 bg-[#2C5282] text-white rounded-md hover:bg-blue-700"
            >
              {isUploading ? "Uploading..." : "Begin Processing"}
            </Button>
          </div>
        </CardContent>
      </Card>
      
      <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center text-red-600">
              <AlertCircle className="mr-2 h-5 w-5" /> Delete All Data
            </AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete all customer records, file history, and processed data. 
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleClearAllData}
              disabled={isDeleting}
              className="bg-red-600 hover:bg-red-700"
            >
              {isDeleting ? "Deleting..." : "Yes, Delete Everything"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}