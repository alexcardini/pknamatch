import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { ChevronDown, ChevronUp } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Customer, DuplicateGroup } from "@/lib/types";
import ExportOptions from "./ExportOptions";

interface DuplicateGroupProps {
  group: DuplicateGroup;
  onMerge: (groupId: string, primaryId: number, recordIds: number[]) => void;
  isSelected?: boolean;
  onToggleSelect?: (groupId: string) => void;
}

function DuplicateGroupItem({ group, onMerge, isSelected, onToggleSelect }: DuplicateGroupProps) {
  const [isExpanded, setIsExpanded] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedRecords, setSelectedRecords] = useState<number[]>(
    group.records.map(record => record.id)
  );
  const [primaryRecordId, setPrimaryRecordId] = useState<number>(group.records[0].id);
  const { toast } = useToast();

  const handleRecordSelection = (recordId: number, isChecked: boolean) => {
    if (isChecked) {
      setSelectedRecords(prev => [...prev, recordId]);
    } else {
      setSelectedRecords(prev => prev.filter(id => id !== recordId));
      
      // If the primary record is unselected, select a new primary
      if (recordId === primaryRecordId && selectedRecords.length > 1) {
        const newPrimaryId = selectedRecords.find(id => id !== recordId);
        if (newPrimaryId) {
          setPrimaryRecordId(newPrimaryId);
        }
      }
    }
  };

  const handlePrimarySelection = (recordId: number) => {
    setPrimaryRecordId(recordId);
    
    // Ensure the primary record is also selected
    if (!selectedRecords.includes(recordId)) {
      setSelectedRecords(prev => [...prev, recordId]);
    }
  };
  
  // Select none or all records
  const handleSelectAll = (selectAll: boolean) => {
    if (selectAll) {
      setSelectedRecords(group.records.map(record => record.id));
    } else {
      setSelectedRecords([]);
    }
  };

  const handleMerge = async () => {
    if (selectedRecords.length < 2) {
      toast({
        title: "Selection error",
        description: "You need to select at least 2 records to merge",
        variant: "destructive"
      });
      return;
    }
    
    setIsProcessing(true);
    try {
      await onMerge(group.id, primaryRecordId, selectedRecords);
      toast({
        title: "Records merged",
        description: `Successfully merged ${selectedRecords.length} records`,
      });
    } catch (error) {
      console.error("Error during merge:", error);
      toast({
        title: "Merge failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className={`border rounded-lg mb-4 ${isSelected ? 'ring-2 ring-blue-500 border-blue-500' : ''}`}>
      <div className="p-4 bg-gray-50 rounded-t-lg border-b">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-3">
            {onToggleSelect && (
              <Checkbox 
                checked={isSelected}
                onCheckedChange={() => onToggleSelect(group.id)}
                className="h-5 w-5"
              />
            )}
            <div>
              <h4 className="font-medium">
                Duplicate Group: <span className="text-[#2C5282]">{group.name}</span>
              </h4>
              <p className="text-sm text-gray-500">
                {group.records.length} potentially related records, {group.confidence}% match confidence
              </p>
              {group.matchReason && (
                <p className="text-xs font-medium mt-1 inline-block px-2 py-1 bg-blue-100 text-blue-800 rounded-full">
                  {group.matchReason}
                </p>
              )}
            </div>
          </div>
          <div className="flex space-x-2">
            {!isExpanded && (
              <Button 
                onClick={() => setIsExpanded(true)}
                variant="ghost" 
                className="p-1 h-8 w-8"
              >
                <ChevronDown className="h-5 w-5" />
              </Button>
            )}
            {isExpanded && (
              <>
                <Button 
                  variant="outline" 
                  className="px-3 py-1 h-auto text-sm"
                  onClick={() => setSelectedRecords([])}
                >
                  Keep Separate
                </Button>
                <Button 
                  variant="default" 
                  className="px-3 py-1 h-auto text-sm bg-[#48BB78] hover:bg-green-700"
                  onClick={handleMerge}
                  disabled={selectedRecords.length < 2 || isProcessing}
                >
                  {isProcessing ? (
                    <div className="flex items-center gap-1">
                      <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Processing...
                    </div>
                  ) : (
                    "Merge Records"
                  )}
                </Button>
                <Button 
                  onClick={() => setIsExpanded(false)}
                  variant="ghost" 
                  className="p-1 h-8 w-8"
                >
                  <ChevronUp className="h-5 w-5" />
                </Button>
              </>
            )}
          </div>
        </div>
      </div>

      {isExpanded && (
        <div className="p-4">
          <div className="overflow-x-auto">
            <table className="min-w-full">
              <thead>
                <tr>
                  <th className="w-px">
                    <Checkbox 
                      checked={selectedRecords.length === group.records.length}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setSelectedRecords(group.records.map(r => r.id));
                        } else {
                          setSelectedRecords([]);
                        }
                      }}
                    />
                  </th>
                  <th>Primary</th>
                  <th>Name</th>
                  <th>Phone</th>
                  <th>Address</th>
                  <th>Zone</th>
                </tr>
              </thead>
              <tbody>
                {group.records.map((record) => (
                  <tr key={record.id}>
                    <td>
                      <Checkbox 
                        checked={selectedRecords.includes(record.id)}
                        onCheckedChange={(checked) => {
                          handleRecordSelection(record.id, !!checked);
                        }}
                      />
                    </td>
                    <td>
                      <RadioGroup value={primaryRecordId.toString()}>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem 
                            value={record.id.toString()} 
                            id={`radio-${record.id}`} 
                            disabled={!selectedRecords.includes(record.id)}
                            onClick={() => handlePrimarySelection(record.id)}
                          />
                        </div>
                      </RadioGroup>
                    </td>
                    <td>{record.firstName} {record.lastName}</td>
                    <td>{record.phone}</td>
                    <td className="max-w-md truncate">{record.address}</td>
                    <td>{record.zone}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

interface DuplicateMergeInterfaceProps {
  duplicateGroups: DuplicateGroup[];
  onMergeComplete: () => void;
}

export default function DuplicateMergeInterface({
  duplicateGroups,
  onMergeComplete,
}: DuplicateMergeInterfaceProps) {
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedGroups, setSelectedGroups] = useState<string[]>([]);
  const [mergedGroups, setMergedGroups] = useState<{
    groupId: string;
    primaryRecord: any;
    mergedRecords: any[];
    matchReason?: string;
  }[]>([]);
  
  // Toggle selection of a duplicate group
  const toggleGroupSelection = (groupId: string) => {
    setSelectedGroups(prev => 
      prev.includes(groupId)
        ? prev.filter(id => id !== groupId)
        : [...prev, groupId]
    );
  };
  
  // Check if all groups are selected
  const allGroupsSelected = selectedGroups.length === duplicateGroups.length;
  
  // Toggle selection of all groups
  const toggleSelectAll = () => {
    if (allGroupsSelected) {
      setSelectedGroups([]);
    } else {
      setSelectedGroups(duplicateGroups.map(group => group.id));
    }
  };

  // Merge selected groups in batch
  const handleMergeSelected = async () => {
    if (selectedGroups.length === 0) {
      toast({
        title: "No groups selected",
        description: "Please select at least one group to merge",
        variant: "destructive"
      });
      return;
    }
    
    setIsProcessing(true);
    setProcessProgress({ current: 0, total: selectedGroups.length });
    
    try {
      // Create batch payload for selected groups only
      const selectedGroupsData = duplicateGroups
        .filter(group => selectedGroups.includes(group.id))
        .map(group => ({
          groupId: group.id,
          primaryId: group.records[0].id,
          recordIds: group.records.map(r => r.id)
        }));
      
      // Prepare merged groups for report
      const selectedGroupsForReport = selectedGroups.map(groupId => {
        const group = duplicateGroups.find(g => g.id === groupId);
        if (!group) return null;
        
        const primaryId = group.records[0].id;
        const primaryRecord = group.records.find(record => record.id === primaryId);
        const mergedRecords = group.records.filter(record => record.id !== primaryId);
        
        return {
          groupId,
          primaryRecord,
          mergedRecords,
          matchReason: group.matchReason
        };
      }).filter(Boolean) as {
        groupId: string;
        primaryRecord: any;
        mergedRecords: any[];
        matchReason?: string;
      }[];
      
      // Process in one batch if small enough
      if (selectedGroupsData.length <= 20) {
        const response = await apiRequest("POST", "/api/merge-duplicates/batch", {
          groups: selectedGroupsData
        });
        
        const data = await response.json();
        
        // Add successful merges to tracked list
        setMergedGroups(prev => [
          ...prev, 
          ...selectedGroupsForReport
        ]);
        
        toast({
          title: "Selected groups merged",
          description: `Successfully merged ${data.successCount} of ${data.totalProcessed} groups.`
        });
      } else {
        // Use chunking for larger selections
        const CHUNK_SIZE = 20;
        let processed = 0;
        let successCount = 0;
        
        for (let i = 0; i < selectedGroupsData.length; i += CHUNK_SIZE) {
          const chunk = selectedGroupsData.slice(i, i + CHUNK_SIZE);
          const response = await apiRequest("POST", "/api/merge-duplicates/batch", {
            groups: chunk
          });
          
          const data = await response.json();
          processed += data.totalProcessed;
          successCount += data.successCount;
          
          setProcessProgress({ current: processed, total: selectedGroupsData.length });
        }
        
        // Add successful merges to tracked list for reporting
        setMergedGroups(prev => [
          ...prev, 
          ...selectedGroupsForReport
        ]);
        
        toast({
          title: "Selected groups merged",
          description: `Successfully merged ${successCount} of ${processed} groups.`
        });
      }
      
      // Clear selection after merge
      setSelectedGroups([]);
      onMergeComplete();
    } catch (error) {
      console.error("Error merging selected groups:", error);
      toast({
        title: "Merge failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
      setProcessProgress(null);
    }
  };

  const handleMerge = async (groupId: string, primaryId: number, recordIds: number[]) => {
    setIsProcessing(true);
    
    try {
      const response = await apiRequest("POST", "/api/merge-duplicates", {
        groupId,
        primaryId,
        recordIds
      });
      
      const data = await response.json();
      
      // Find the group that was merged
      const mergedGroup = duplicateGroups.find(group => group.id === groupId);
      if (mergedGroup) {
        // Get the primary record
        const primaryRecord = mergedGroup.records.find(record => record.id === primaryId);
        
        // Get all other records
        const secondaryRecords = mergedGroup.records.filter(
          record => record.id !== primaryId && recordIds.includes(record.id)
        );
        
        // Add to merged groups for reporting
        if (primaryRecord) {
          setMergedGroups(prev => [...prev, {
            groupId,
            primaryRecord, 
            mergedRecords: secondaryRecords,
            matchReason: mergedGroup.matchReason
          }]);
        }
      }
      
      toast({
        title: "Records merged successfully",
        description: `Primary record: ${data.primaryRecord.firstName} ${data.primaryRecord.lastName}`,
      });
      
      onMergeComplete();
    } catch (error) {
      console.error("Error merging records:", error);
      toast({
        title: "Merge failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const [processProgress, setProcessProgress] = useState<{ current: number, total: number } | null>(null);
  
  const handleAutoResolveAll = async () => {
    setIsProcessing(true);
    setProcessProgress({ current: 0, total: duplicateGroups.length });
    
    try {
      // Prepare all groups for reporting
      const allGroupsForReport = duplicateGroups.map(group => {
        const primaryId = group.records[0].id;
        const primaryRecord = group.records.find(record => record.id === primaryId);
        const mergedRecords = group.records.filter(record => record.id !== primaryId);
        
        return {
          groupId: group.id,
          primaryRecord,
          mergedRecords,
          matchReason: group.matchReason
        };
      }).filter(g => g.primaryRecord && g.mergedRecords.length > 0);
      
      // For very large datasets, process in chunks to provide progress feedback
      const CHUNK_SIZE = 20; // Process 20 groups at a time
      let processed = 0;
      let successCount = 0;
      
      // Process in chunks for better UX with progress indicators
      for (let i = 0; i < duplicateGroups.length; i += CHUNK_SIZE) {
        const chunk = duplicateGroups.slice(i, i + CHUNK_SIZE);
        const batchGroups = chunk.map(group => ({
          groupId: group.id,
          primaryId: group.records[0].id,
          recordIds: group.records.map(r => r.id)
        }));
        
        // Use the batch endpoint for better performance
        const response = await apiRequest("POST", "/api/merge-duplicates/batch", {
          groups: batchGroups
        });
        
        const data = await response.json();
        processed += data.totalProcessed;
        successCount += data.successCount;
        
        // Update progress
        setProcessProgress({ current: processed, total: duplicateGroups.length });
      }
      
      // Add all successful merges to tracked list for reporting
      setMergedGroups(prev => [...prev, ...allGroupsForReport]);
      
      toast({
        title: "Auto-resolve complete",
        description: `Successfully merged ${successCount} of ${processed} groups.`
      });
      
      onMergeComplete();
    } catch (error) {
      console.error("Error auto-resolving:", error);
      toast({
        title: "Auto-resolve failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
      setProcessProgress(null);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <div className="px-6 py-4 border-b border-gray-200">
          <h2 className="text-xl font-semibold">
            Potential Duplicates ({duplicateGroups.length} groups need review)
          </h2>
        </div>

        <CardContent className="p-6">
          <div className="mb-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-medium">Manual Review Required</h3>
              <div className="flex space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleAutoResolveAll}
                  disabled={isProcessing}
                >
                  {isProcessing ? (
                    <div className="flex items-center gap-1">
                      <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-gray-700" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Processing...
                    </div>
                  ) : (
                    "Auto-Resolve All"
                  )}
                </Button>
                <Button
                  variant="default"
                  size="sm"
                  className="bg-[#2C5282]"
                  onClick={() => {
                    // Open all duplicate groups for review
                    const accordionButtons = document.querySelectorAll('[data-state="closed"]');
                    accordionButtons.forEach((button: Element) => {
                      if (button instanceof HTMLButtonElement) {
                        button.click();
                      }
                    });
                  }}
                >
                  Expand All Groups
                </Button>
              </div>
            </div>
            
            {processProgress && (
              <div className="mb-4">
                <div className="flex items-center justify-between mb-1 text-sm">
                  <span>Processing duplicate groups...</span>
                  <span>{processProgress.current} of {processProgress.total} ({Math.round((processProgress.current / processProgress.total) * 100)}%)</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div 
                    className="bg-[#48BB78] h-2.5 rounded-full" 
                    style={{ width: `${(processProgress.current / processProgress.total) * 100}%` }}
                  ></div>
                </div>
              </div>
            )}

            {/* Bulk selection controls */}
            <div className="mb-4 flex items-center justify-between bg-gray-50 p-3 rounded-lg border">
              <div className="flex items-center gap-2">
                <Checkbox 
                  id="select-all-groups"
                  checked={allGroupsSelected && duplicateGroups.length > 0}
                  onCheckedChange={() => toggleSelectAll()}
                />
                <Label htmlFor="select-all-groups" className="text-sm font-medium">
                  Select All Groups ({selectedGroups.length}/{duplicateGroups.length})
                </Label>
              </div>
              
              {selectedGroups.length > 0 && (
                <Button
                  variant="default"
                  size="sm"
                  className="bg-[#48BB78] hover:bg-green-700"
                  onClick={handleMergeSelected}
                  disabled={isProcessing}
                >
                  {isProcessing ? (
                    <div className="flex items-center gap-1">
                      <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Processing...
                    </div>
                  ) : (
                    `Merge Selected (${selectedGroups.length})`
                  )}
                </Button>
              )}
            </div>
            
            {duplicateGroups.map((group) => (
              <DuplicateGroupItem
                key={group.id}
                group={group}
                onMerge={handleMerge}
                isSelected={selectedGroups.includes(group.id)}
                onToggleSelect={toggleGroupSelection}
              />
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Export Options Section */}
      {mergedGroups.length > 0 && (
        <ExportOptions 
          processedGroups={duplicateGroups}
          mergedGroups={mergedGroups}
          showMergeReport={true}
        />
      )}
    </div>
  );
}
