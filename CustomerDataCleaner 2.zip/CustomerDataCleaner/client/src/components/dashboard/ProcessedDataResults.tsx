import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { ChevronRight, Download, Check, Search, List } from "lucide-react";
import { Customer } from "@/lib/types";
import CustomerCard from "@/components/customer/CustomerCard";
import { saveAs } from "file-saver";

interface ProcessedDataResultsProps {
  customers: Customer[];
}

export default function ProcessedDataResults({ customers }: ProcessedDataResultsProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedZone, setSelectedZone] = useState("all");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  // Get all unique zones from customers
  const zones = Array.from(new Set(customers.map(customer => customer.zone))).filter(Boolean);

  // Filter customers by search term and zone
  const filteredCustomers = customers.filter(customer => {
    const matchesSearch =
      searchTerm === "" ||
      `${customer.firstName} ${customer.lastName}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.phone.includes(searchTerm) ||
      customer.address.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (customer.zone && customer.zone.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesZone = selectedZone === "all" || customer.zone === selectedZone;

    return matchesSearch && matchesZone;
  });

  // Calculate pagination
  const totalPages = Math.ceil(filteredCustomers.length / itemsPerPage);
  const paginatedCustomers = filteredCustomers.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const handleExportCSV = () => {
    // Create CSV content
    let csvContent = "Customer ID,First Name,Last Name,Phone,Address,Zone,Status\n";
    
    filteredCustomers.forEach(customer => {
      csvContent += `${customer.customerId},${customer.firstName},${customer.lastName},${customer.phone},"${customer.address}",${customer.zone || ""},${customer.status}\n`;
    });
    
    // Create blob and download
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8" });
    saveAs(blob, `customer-data-export-${new Date().toISOString().split('T')[0]}.csv`);
  };

  return (
    <Card>
      <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
        <h2 className="text-xl font-semibold">Processed Customer Data</h2>
        <div className="flex space-x-2">
          <Button
            variant="outline"
            className="px-4 py-2 border border-gray-300 flex items-center"
            onClick={handleExportCSV}
          >
            <Download className="h-4 w-4 mr-2" />
            Export CSV
          </Button>
          <Button className="px-4 py-2 bg-[#2C5282] text-white flex items-center">
            <Check className="h-4 w-4 mr-2" />
            Finalize Changes
          </Button>
        </div>
      </div>

      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative">
              <Select value={selectedZone} onValueChange={setSelectedZone}>
                <SelectTrigger className="pl-10 w-40">
                  <List className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 h-5 w-5" />
                  <SelectValue placeholder="All Zones" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Zones</SelectItem>
                  {zones.map(zone => (
                    <SelectItem key={zone} value={zone}>
                      {zone}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 h-5 w-5" />
              <Input
                type="search"
                placeholder="Search customers..."
                className="pl-10 w-full md:w-64"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          <div className="text-sm text-gray-500 hidden md:block">
            Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
            {Math.min(currentPage * itemsPerPage, filteredCustomers.length)} of{" "}
            {filteredCustomers.length} results
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead>
              <tr>
                <th className="w-36">
                  <div className="flex items-center">
                    Customer ID
                    <Button variant="ghost" size="sm" className="p-0 ml-1">
                      <ChevronRight className="h-4 w-4 transform rotate-90" />
                    </Button>
                  </div>
                </th>
                <th>
                  <div className="flex items-center">
                    Name
                    <Button variant="ghost" size="sm" className="p-0 ml-1">
                      <ChevronRight className="h-4 w-4 transform rotate-90" />
                    </Button>
                  </div>
                </th>
                <th>Phone</th>
                <th>Address</th>
                <th>
                  <div className="flex items-center">
                    Zone
                    <Button variant="ghost" size="sm" className="p-0 ml-1">
                      <ChevronRight className="h-4 w-4 transform rotate-90" />
                    </Button>
                  </div>
                </th>
                <th>
                  <div className="flex items-center">
                    Orders
                    <Button variant="ghost" size="sm" className="p-0 ml-1">
                      <ChevronRight className="h-4 w-4 transform rotate-90" />
                    </Button>
                  </div>
                </th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {paginatedCustomers.map((customer) => (
                <tr key={customer.id}>
                  <td>{customer.customerId}</td>
                  <td>
                    <CustomerCard customer={customer} />
                  </td>
                  <td>{customer.phone}</td>
                  <td className="max-w-md truncate">{customer.address}</td>
                  <td>{customer.zone}</td>
                  <td>
                    {customer.orderHistory && customer.orderHistory.length > 0 ? (
                      <div className="flex flex-col">
                        <span className="font-medium text-xs">{customer.orderHistory.length} orders</span>
                        {customer.totalSpent && (
                          <span className="text-xs text-gray-500">
                            ${parseFloat(customer.totalSpent.toString()).toFixed(2)}
                          </span>
                        )}
                      </div>
                    ) : (
                      <span className="text-xs text-gray-500">No orders</span>
                    )}
                  </td>
                  <td>
                    <span className={`px-2 py-1 rounded-full text-xs ${
                      customer.status === 'clean' ? 'bg-green-100 text-green-800' : 
                      customer.status === 'merged' ? 'bg-yellow-100 text-yellow-800' : 
                      'bg-orange-100 text-orange-800'
                    }`}>
                      {customer.status === 'clean' ? 'Clean' : 
                       customer.status === 'merged' ? 'Merged' : 'For Review'}
                    </span>
                  </td>
                  <td>
                    <Link href={`/customers/${customer.id}`}>
                      <Button variant="ghost" size="icon" className="text-[#2C5282] hover:text-blue-700">
                        <ChevronRight className="h-5 w-5" />
                      </Button>
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-6 flex flex-col md:flex-row items-center justify-between">
          <div className="text-sm text-gray-500 mb-4 md:mb-0">
            Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
            {Math.min(currentPage * itemsPerPage, filteredCustomers.length)} of{" "}
            {filteredCustomers.length} results
          </div>
          <div className="flex space-x-1">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(currentPage - 1)}
              disabled={currentPage === 1}
            >
              Previous
            </Button>
            {Array.from({ length: Math.min(totalPages, 3) }, (_, i) => {
              const pageNumber = currentPage <= 2 ? i + 1 : currentPage - 1 + i;
              if (pageNumber <= totalPages) {
                return (
                  <Button
                    key={pageNumber}
                    variant={pageNumber === currentPage ? "default" : "outline"}
                    size="sm"
                    onClick={() => setCurrentPage(pageNumber)}
                    className={pageNumber === currentPage ? "bg-[#2C5282]" : ""}
                  >
                    {pageNumber}
                  </Button>
                );
              }
              return null;
            })}
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(currentPage + 1)}
              disabled={currentPage === totalPages}
            >
              Next
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
