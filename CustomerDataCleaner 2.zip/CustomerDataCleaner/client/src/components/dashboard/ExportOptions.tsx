import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { DuplicateGroup } from "@/lib/types";
import { FileText, FileSpreadsheet, Download, Filter } from "lucide-react";
import { useState } from "react";
import { saveAs } from "file-saver";

interface ExportOptionsProps {
  processedGroups: DuplicateGroup[];
  mergedGroups: {
    groupId: string;
    primaryRecord: any;
    mergedRecords: any[];
    matchReason?: string;
  }[];
  showMergeReport: boolean;
}

export default function ExportOptions({ 
  processedGroups, 
  mergedGroups,
  showMergeReport 
}: ExportOptionsProps) {
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [isGeneratingCsv, setIsGeneratingCsv] = useState(false);
  const [isGeneratingUniquesCsv, setIsGeneratingUniquesCsv] = useState(false);

  const generateMergeReport = async () => {
    if (mergedGroups.length === 0) {
      toast({
        title: "No merges to report",
        description: "There are no merged groups to include in the report.",
        variant: "destructive"
      });
      return;
    }

    try {
      setIsGeneratingPdf(true);
      
      // Clean and normalize the data to avoid payload issues
      const cleanedMergedGroups = mergedGroups.map(group => {
        // Create a simplified version of each record with only the needed fields
        const simplifiedPrimaryRecord = {
          id: group.primaryRecord.id,
          customerId: group.primaryRecord.customerId || 'N/A',
          firstName: group.primaryRecord.firstName || '',
          lastName: group.primaryRecord.lastName || '',
          phone: group.primaryRecord.phone || '',
          address: group.primaryRecord.address || '',
          zone: group.primaryRecord.zone || null
        };
        
        // Create simplified merged records
        const simplifiedMergedRecords = group.mergedRecords.map(record => ({
          id: record.id,
          customerId: record.customerId || 'N/A',
          firstName: record.firstName || '',
          lastName: record.lastName || '',
          phone: record.phone || '',
          address: record.address || '',
          zone: record.zone || null
        }));
        
        return {
          groupId: group.groupId,
          primaryRecord: simplifiedPrimaryRecord,
          mergedRecords: simplifiedMergedRecords,
          matchReason: group.matchReason
        };
      });
      
      const reportData = {
        mergeDate: new Date().toISOString(),
        mergedGroups: cleanedMergedGroups,
        totalMerges: mergedGroups.length
      };
      
      const response = await apiRequest("POST", '/api/reports/merge-pdf', reportData);
      
      if (!response.ok) {
        throw new Error("Failed to generate PDF report");
      }
      
      const data = await response.json();
      
      // Create a download link
      const downloadUrl = window.location.origin + data.downloadUrl;
      
      // Either open in new tab or download directly
      window.open(downloadUrl, '_blank');
      
      toast({
        title: "PDF Report Generated",
        description: "The merged customers report has been generated successfully."
      });
    } catch (error) {
      console.error("Error generating PDF report:", error);
      toast({
        title: "Error",
        description: "Failed to generate PDF report. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  // Export all consolidated customers (includes both merged and non-merged)
  const exportCustomersCsv = async () => {
    try {
      setIsGeneratingCsv(true);
      
      // Check if we have merged groups that should be included in the export
      if (mergedGroups.length > 0) {
        // Export directly from the UI with merged groups data
        // First create a simplified CSV format from merged groups
        const csvHeader = 'Customer ID,First Name,Last Name,Phone,Address,Zone,Is Merged,Merged From,Match Reason\n';
        const csvRows: string[] = [];
        
        // Add primary records first
        mergedGroups.forEach(group => {
          const record = group.primaryRecord;
          if (record) {
            csvRows.push([
              record.customerId || 'N/A',
              `"${record.firstName || ''}"`, 
              `"${record.lastName || ''}"`,
              `"${record.phone || ''}"`,
              `"${record.address || ''}"`,
              `"${record.zone || ''}"`,
              'Yes',
              `"${group.mergedRecords.map(r => r.customerId || 'N/A').join(', ')}"`,
              `"${group.matchReason || 'Manual Merge'}"`
            ].join(','));
          }
          
          // We don't add the secondary records as they're merged into the primary
        });
        
        // Create CSV content 
        const csvContent = csvHeader + csvRows.join('\n');
        
        // Generate a Blob and download using FileSaver.js
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        saveAs(blob, `merged-customers-${timestamp}.csv`);
        
        toast({
          title: "CSV Export Complete",
          description: "The merged customer data has been exported successfully."
        });
      } else {
        // If no merged groups in UI, fall back to server export
        const response = await apiRequest("GET", '/api/export/customers-csv');
        
        if (!response.ok) {
          throw new Error("Failed to generate CSV file");
        }
        
        const data = await response.json();
        
        // Create a download link
        const downloadUrl = window.location.origin + data.downloadUrl;
        
        // Download the file
        window.location.href = downloadUrl;
        
        toast({
          title: "CSV Export Complete",
          description: `Successfully exported ${data.recordCount || "all"} consolidated customer records (primary + non-merged).`
        });
      }
    } catch (error) {
      console.error("Error exporting CSV:", error);
      toast({
        title: "Error",
        description: "Failed to export customer data. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsGeneratingCsv(false);
    }
  };

  // Export ONLY unique customers (clean records + primary merged records)
  const exportUniqueCustomersCsv = async () => {
    try {
      setIsGeneratingUniquesCsv(true);
      
      // Always use the server endpoint for this since it requires special filtering
      const response = await apiRequest("GET", '/api/export/unique-customers-csv');
      
      if (!response.ok) {
        throw new Error("Failed to generate unique customers CSV file");
      }
      
      const data = await response.json();
      
      // Create a download link
      const downloadUrl = window.location.origin + data.downloadUrl;
      
      // Download the file
      window.location.href = downloadUrl;
      
      toast({
        title: "Unique Customers Export Complete",
        description: `Successfully exported ${data.recordCount} unique customer records.`
      });
    } catch (error) {
      console.error("Error exporting unique customers CSV:", error);
      toast({
        title: "Error",
        description: "Failed to export unique customer data. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsGeneratingUniquesCsv(false);
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-lg font-medium">Export Options</CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {showMergeReport && (
            <Button 
              onClick={generateMergeReport} 
              className="w-full flex items-center gap-2"
              disabled={isGeneratingPdf || mergedGroups.length === 0}
              variant="default"
            >
              <FileText className="h-4 w-4" />
              {isGeneratingPdf ? "Generating..." : "Generate Merge Report (PDF)"}
            </Button>
          )}
          
          <Button 
            onClick={exportCustomersCsv} 
            className="w-full flex items-center gap-2"
            disabled={isGeneratingCsv}
            variant="outline"
          >
            <FileSpreadsheet className="h-4 w-4" />
            {isGeneratingCsv ? "Exporting..." : "Export All Consolidated Data"}
          </Button>
          
          <Button 
            onClick={exportUniqueCustomersCsv} 
            className="w-full flex items-center gap-2"
            disabled={isGeneratingUniquesCsv}
            variant="outline"
          >
            <Filter className="h-4 w-4" />
            {isGeneratingUniquesCsv ? "Exporting..." : "Export Unique Customers Only"}
          </Button>
        </div>
        
        <div className="text-xs text-slate-500 mt-2">
          <p>
            • <strong>All Consolidated Data</strong>: Includes all valid customer records (original records + primary merged records, excludes only those marked as "merged into" others)
          </p>
          <p>
            • <strong>Unique Customers Only</strong>: Includes only one record per unique customer (removes all duplicate records)
          </p>
          <p>
            • <strong>Merge Report (PDF)</strong>: Detailed information about all merged groups and match reasons
          </p>
          <p>
            • All exports include order history and customer details where available
          </p>
          <p>
            • CSV files can be imported into Excel, Google Sheets or other data analysis tools
          </p>
        </div>
      </CardContent>
    </Card>
  );
}