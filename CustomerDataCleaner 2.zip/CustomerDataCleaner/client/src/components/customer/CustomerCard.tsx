import { Customer } from "@/lib/types";

interface CustomerCardProps {
  customer: Customer;
}

export default function CustomerCard({ customer }: CustomerCardProps) {
  // Create initials from the customer's name
  const initials = `${customer.firstName.charAt(0)}${customer.lastName.charAt(0)}`;
  
  // Determine if this customer is a merged record
  const isMerged = customer.isMerged;
  
  // Determine the number of merged records if any
  const mergedCount = customer.mergedFrom?.length || 0;
  
  // Get the customer's label to display below the name
  const getCustomerLabel = () => {
    if (isMerged && mergedCount > 0) {
      return `Merged ${mergedCount} records`;
    }
    return "Original record";
  };
  
  return (
    <div className="flex items-center">
      <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-sm font-semibold text-[#2C5282]">
        {initials}
      </div>
      <div className="ml-3">
        <div className="font-medium">{customer.firstName} {customer.lastName}</div>
        <div className="text-xs text-gray-500">{getCustomerLabel()}</div>
      </div>
    </div>
  );
}
