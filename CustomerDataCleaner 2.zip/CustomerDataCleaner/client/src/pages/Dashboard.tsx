import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import DataImportSection from "@/components/dashboard/DataImportSection";
import ProcessingStatus from "@/components/dashboard/ProcessingStatus";
import DuplicateMergeInterface from "@/components/dashboard/DuplicateMergeInterface";
import ProcessedDataResults from "@/components/dashboard/ProcessedDataResults";
import { Customer, DuplicateGroup } from "@/lib/types";

export default function Dashboard() {
  const [processingStage, setProcessingStage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [duplicateGroups, setDuplicateGroups] = useState<DuplicateGroup[]>([]);
  
  // Fetch customers data
  const { data: customers, isLoading, refetch } = useQuery<Customer[]>({
    queryKey: ["/api/customers"],
  });

  // Fetch file history
  const { data: fileHistory } = useQuery({
    queryKey: ["/api/file-history"],
    enabled: !isLoading,
  });

  // Fetch analytics data
  const { data: analytics } = useQuery({
    queryKey: ["/api/analytics"],
    enabled: !isLoading,
  });

  const handleFileUploaded = async () => {
    setProcessingStage("validation");
    setIsProcessing(true);
    setUploadProgress(25);
    
    // Simulate processing steps with timeouts
    setTimeout(() => {
      setProcessingStage("fuzzyMatching");
      setUploadProgress(50);
      
      setTimeout(() => {
        setProcessingStage("recordMerging");
        setUploadProgress(75);
        
        // Fetch the duplicate records
        fetch("/api/find-duplicates")
          .then(res => res.json())
          .then(data => {
            setDuplicateGroups(data.duplicateGroups);
            setProcessingStage("idAssignment");
            setUploadProgress(90);
            
            setTimeout(() => {
              setProcessingStage("databaseUpdate");
              setUploadProgress(100);
              setIsProcessing(false);
              refetch();
            }, 1000);
          });
      }, 1500);
    }, 1000);
  };

  const handleMergeDuplicates = () => {
    // Refresh the data after merging
    refetch();
  };

  return (
    <div className="p-6 bg-[#F7FAFC]">
      {/* Data Import Section */}
      <div className="mb-8">
        <DataImportSection 
          onFileUploaded={handleFileUploaded} 
          recentFiles={fileHistory || []}
        />
      </div>

      {/* Processing Status - show only when processing */}
      {(isProcessing || processingStage) && (
        <div className="mb-8">
          <ProcessingStatus 
            stage={processingStage || ""}
            progress={uploadProgress}
            totalRecords={customers?.length || 0}
            potentialDuplicates={duplicateGroups.length}
          />
        </div>
      )}

      {/* Duplicate Merge Interface - show only when duplicates found */}
      {duplicateGroups.length > 0 && (
        <div className="mb-8">
          <DuplicateMergeInterface 
            duplicateGroups={duplicateGroups}
            onMergeComplete={handleMergeDuplicates}
          />
        </div>
      )}

      {/* Processed Data Results */}
      <ProcessedDataResults customers={customers || []} />
    </div>
  );
}
