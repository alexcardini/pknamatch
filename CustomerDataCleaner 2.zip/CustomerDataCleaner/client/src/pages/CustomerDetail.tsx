import { useQuery } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { ArrowLeft, User, Phone, MapPin, Tag, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import CustomerCard from "@/components/customer/CustomerCard";
import { Customer } from "@/lib/types";

export default function CustomerDetail() {
  // Get customer ID from route parameter
  const [match, params] = useRoute("/customers/:id");
  const id = params?.id ? parseInt(params.id) : null;

  // Fetch customer data
  const { data: customer, isLoading, error } = useQuery<Customer>({
    queryKey: [`/api/customers/${id}`],
    enabled: !!id,
  });

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="mb-6">
          <Button variant="outline" size="sm" asChild>
            <Link href="/">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Dashboard
            </Link>
          </Button>
        </div>
        <Card>
          <CardHeader>
            <Skeleton className="h-8 w-64" />
          </CardHeader>
          <CardContent>
            <div className="grid gap-6">
              <Skeleton className="h-32 w-full" />
              <Skeleton className="h-64 w-full" />
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (error || !customer) {
    return (
      <div className="p-6">
        <div className="mb-6">
          <Button variant="outline" size="sm" asChild>
            <Link href="/">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Dashboard
            </Link>
          </Button>
        </div>
        <Card>
          <CardHeader>
            <CardTitle>Error</CardTitle>
          </CardHeader>
          <CardContent>
            <p>Failed to load customer information. Please try again.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="mb-6">
        <Button variant="outline" size="sm" asChild>
          <Link href="/">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Dashboard
          </Link>
        </Button>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex justify-between items-center">
            <CardTitle className="text-2xl font-bold flex items-center">
              <div className="w-10 h-10 rounded-full bg-[#2C5282] text-white flex items-center justify-center mr-3 text-lg">
                {customer.firstName.charAt(0)}{customer.lastName.charAt(0)}
              </div>
              Customer Details
            </CardTitle>
            <div>
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                customer.status === 'clean' ? 'bg-green-100 text-green-800' : 
                customer.status === 'merged' ? 'bg-yellow-100 text-yellow-800' : 
                'bg-orange-100 text-orange-800'
              }`}>
                {customer.status === 'clean' ? 'Clean' : 
                 customer.status === 'merged' ? 'Merged' : 'For Review'}
              </span>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-semibold mb-4">Basic Information</h3>
              <div className="space-y-4">
                <div className="flex items-start">
                  <User className="h-5 w-5 text-[#2C5282] mr-3 mt-0.5" />
                  <div>
                    <p className="font-medium">Name</p>
                    <p className="text-gray-600">{customer.firstName} {customer.lastName}</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <Phone className="h-5 w-5 text-[#2C5282] mr-3 mt-0.5" />
                  <div>
                    <p className="font-medium">Phone</p>
                    <p className="text-gray-600">{customer.phone}</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <MapPin className="h-5 w-5 text-[#2C5282] mr-3 mt-0.5" />
                  <div>
                    <p className="font-medium">Address</p>
                    <p className="text-gray-600">{customer.address}</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <Tag className="h-5 w-5 text-[#2C5282] mr-3 mt-0.5" />
                  <div>
                    <p className="font-medium">Zone</p>
                    <p className="text-gray-600">{customer.zone || 'Not specified'}</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <FileText className="h-5 w-5 text-[#2C5282] mr-3 mt-0.5" />
                  <div>
                    <p className="font-medium">Customer ID</p>
                    <p className="text-gray-600">{customer.customerId}</p>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Merge Information</h3>
              {customer.isMerged ? (
                <div>
                  <p className="mb-4">This record was created by merging multiple customer records.</p>
                  
                  {customer.mergedFrom && customer.mergedFrom.length > 0 && (
                    <div>
                      <p className="font-medium mb-2">Merged from:</p>
                      <ul className="list-disc list-inside text-gray-600 space-y-1">
                        {customer.mergedFrom.map((id, index) => (
                          <li key={index}>{id}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              ) : (
                <p>This is an original customer record with no merges.</p>
              )}
              
              <Separator className="my-6" />
              
              <h3 className="text-lg font-semibold mb-4">Order History</h3>
              {customer.orderHistory && customer.orderHistory.length > 0 ? (
                <div>
                  {customer.totalSpent && (
                    <div className="bg-blue-50 p-4 rounded-md mb-4">
                      <p className="font-medium">Total Spent</p>
                      <p className="text-2xl font-bold text-[#2C5282]">
                        ${parseFloat(customer.totalSpent.toString()).toFixed(2)}
                      </p>
                      {customer.lastOrderDate && (
                        <p className="text-sm text-gray-600 mt-1">
                          Last order: {new Date(customer.lastOrderDate).toLocaleDateString()}
                        </p>
                      )}
                    </div>
                  )}
                  
                  <div className="space-y-4">
                    {customer.orderHistory.map((order, index) => (
                      <div key={index} className="border rounded-md p-4">
                        <div className="flex justify-between items-center mb-2">
                          <h4 className="font-medium">Order #{order.orderId}</h4>
                          <p className="text-sm text-gray-600">{order.date}</p>
                        </div>
                        
                        <div className="mt-3">
                          <table className="min-w-full text-sm">
                            <thead>
                              <tr className="border-b">
                                <th className="text-left py-2">Product</th>
                                <th className="text-right py-2">Qty</th>
                                <th className="text-right py-2">Price</th>
                                <th className="text-right py-2">Total</th>
                              </tr>
                            </thead>
                            <tbody>
                              {order.products.map((item, itemIndex) => (
                                <tr key={itemIndex} className="border-b border-gray-100">
                                  <td className="py-2">{item.name}</td>
                                  <td className="text-right py-2">{item.quantity}</td>
                                  <td className="text-right py-2">${item.unitPrice.toFixed(2)}</td>
                                  <td className="text-right py-2 font-medium">
                                    ${(item.quantity * item.unitPrice).toFixed(2)}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                            <tfoot>
                              <tr>
                                <td colSpan={3} className="text-right py-2 font-medium">Total</td>
                                <td className="text-right py-2 font-bold">${order.totalAmount.toFixed(2)}</td>
                              </tr>
                            </tfoot>
                          </table>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <p className="text-gray-600">
                  No order history is available for this customer.
                </p>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
