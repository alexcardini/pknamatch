import { useState } from "react";
import stringSimilarity from "string-similarity";
import { Customer, DuplicateGroup } from "@/lib/types";
import { v4 as uuidv4 } from "uuid";

// Match reason types
type MatchReason = 'phone_match' | 'full_name_match' | 'fuzzy_match' | 'empty_record_match';

// Configuration for duplicate detection
interface DuplicateDetectionConfig {
  similarityThreshold: number;
  compareFields: ('firstName' | 'lastName' | 'phone' | 'address' | 'zone')[];
  fieldWeights: Record<string, number>;
  phoneAsDefinitiveDuplicate: boolean;
  useFullNameMatching: boolean;
  linkEmptyRecords: boolean;
}

// Default configuration
const defaultConfig: DuplicateDetectionConfig = {
  similarityThreshold: 0.7,
  compareFields: ['firstName', 'lastName'],
  fieldWeights: {
    firstName: 0.5,
    lastName: 0.4,
    phone: 0.9,
    address: 0.2,
    zone: 0.1
  },
  phoneAsDefinitiveDuplicate: true,
  useFullNameMatching: true,
  linkEmptyRecords: true
};

export function useDuplicateDetection(config: Partial<DuplicateDetectionConfig> = {}) {
  const [duplicateGroups, setDuplicateGroups] = useState<DuplicateGroup[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  
  // Merge configuration with defaults
  const effectiveConfig: DuplicateDetectionConfig = {
    ...defaultConfig,
    ...config,
    fieldWeights: { ...defaultConfig.fieldWeights, ...config.fieldWeights }
  };
  
  // Calculate similarity between two strings
  const calculateSimilarity = (str1: string | undefined, str2: string | undefined): number => {
    if (!str1 || !str2) return 0;
    
    return stringSimilarity.compareTwoStrings(
      str1.toLowerCase().trim(),
      str2.toLowerCase().trim()
    );
  };
  
  // Check for exact phone match (definitive match)
  const isPhoneMatch = (customer1: Customer, customer2: Customer): boolean => {
    if (!effectiveConfig.phoneAsDefinitiveDuplicate) return false;
    
    // Clean and normalize phone numbers before comparison
    const normalizePhone = (phone: string) => {
      return phone.replace(/\s+/g, '').replace(/[-()]/g, '').trim();
    };
    
    if (!customer1.phone || !customer2.phone) return false;
    
    return normalizePhone(customer1.phone) === normalizePhone(customer2.phone);
  };
  
  // Check for full name match
  const isFullNameMatch = (customer1: Customer, customer2: Customer): boolean => {
    if (!effectiveConfig.useFullNameMatching) return false;
    
    if (!customer1.firstName || !customer1.lastName || !customer2.firstName || !customer2.lastName) {
      return false;
    }
    
    const fullName1 = `${customer1.firstName.toLowerCase().trim()} ${customer1.lastName.toLowerCase().trim()}`;
    const fullName2 = `${customer2.firstName.toLowerCase().trim()} ${customer2.lastName.toLowerCase().trim()}`;
    
    return fullName1 === fullName2;
  };
  
  // Check if customer is an empty record (no order history, etc.)
  const isEmptyRecord = (customer: Customer): boolean => {
    return customer.emptyRecord === true || 
      (!customer.orderHistory || customer.orderHistory.length === 0);
  };
  
  // Calculate match type and similarity between two customers
  const evaluateMatch = (customer1: Customer, customer2: Customer): { 
    isMatch: boolean;
    similarity: number;
    reason: MatchReason | null;
  } => {
    // Check for phone match first (definitive match)
    if (isPhoneMatch(customer1, customer2)) {
      return { isMatch: true, similarity: 1.0, reason: 'phone_match' };
    }
    
    // Check for full name match
    if (isFullNameMatch(customer1, customer2)) {
      return { isMatch: true, similarity: 0.95, reason: 'full_name_match' };
    }
    
    // Check if one is an empty record that should be linked by name
    if (effectiveConfig.linkEmptyRecords && 
        (isEmptyRecord(customer1) || isEmptyRecord(customer2))) {
      
      // Check for partial name match for empty records
      const firstNameMatch = calculateSimilarity(customer1.firstName, customer2.firstName) > 0.8;
      const lastNameMatch = calculateSimilarity(customer1.lastName, customer2.lastName) > 0.8;
      
      if (firstNameMatch && lastNameMatch) {
        return { isMatch: true, similarity: 0.85, reason: 'empty_record_match' };
      }
    }
    
    // Fall back to traditional fuzzy matching
    let totalSimilarity = 0;
    let totalWeight = 0;
    
    // Compare each field based on config
    for (const field of effectiveConfig.compareFields) {
      const weight = effectiveConfig.fieldWeights[field] || 0;
      const similarity = calculateSimilarity(customer1[field], customer2[field]);
      
      totalSimilarity += similarity * weight;
      totalWeight += weight;
    }
    
    const finalSimilarity = totalWeight > 0 ? totalSimilarity / totalWeight : 0;
    
    return { 
      isMatch: finalSimilarity >= effectiveConfig.similarityThreshold,
      similarity: finalSimilarity,
      reason: finalSimilarity >= effectiveConfig.similarityThreshold ? 'fuzzy_match' : null
    };
  };
  
  // Find potential duplicates in a list of customers
  const findDuplicates = (customers: Customer[]) => {
    setIsProcessing(true);
    
    try {
      const groups: DuplicateGroup[] = [];
      const processed = new Set<number>();
      
      // First pass: Group by phone number (strongest matches)
      const phoneGroups = new Map<string, Customer[]>();
      
      for (const customer of customers) {
        if (processed.has(customer.id)) continue;
        
        const phone = (customer.phone || '').replace(/\s+/g, '').replace(/[-()]/g, '').trim();
        if (phone) {
          if (!phoneGroups.has(phone)) {
            phoneGroups.set(phone, []);
          }
          phoneGroups.get(phone)!.push(customer);
          processed.add(customer.id);
        }
      }
      
      // Convert phone groups to duplicate groups
      phoneGroups.forEach((members, phone) => {
        if (members.length > 1) {
          const mainCustomer = members[0];
          const mainName = `${mainCustomer.firstName} ${mainCustomer.lastName}`;
          
          groups.push({
            id: uuidv4(),
            name: mainName,
            records: members,
            confidence: 95,
            matchReason: 'Phone number exact match'
          });
        }
      });
      
      // Second pass: Group by exact full name match for records without phones
      const nameGroups = new Map<string, Customer[]>();
      
      for (const customer of customers) {
        if (processed.has(customer.id)) continue;
        
        const fullName = `${customer.firstName?.toLowerCase().trim() || ''} ${customer.lastName?.toLowerCase().trim() || ''}`.trim();
        if (fullName) {
          if (!nameGroups.has(fullName)) {
            nameGroups.set(fullName, []);
          }
          nameGroups.get(fullName)!.push(customer);
          processed.add(customer.id);
        }
      }
      
      // Convert name groups to duplicate groups
      nameGroups.forEach((members, name) => {
        if (members.length > 1) {
          groups.push({
            id: uuidv4(),
            name,
            records: members,
            confidence: 90,
            matchReason: 'Full name exact match'
          });
        }
      });
      
      // Third pass: Use fuzzy matching for remaining records
      for (let i = 0; i < customers.length; i++) {
        if (processed.has(customers[i].id)) continue;
        
        const potentialGroup: { 
          customer: Customer; 
          similarity: number;
          reason: MatchReason | null;
        }[] = [{ 
          customer: customers[i], 
          similarity: 1.0, 
          reason: null 
        }];
        
        processed.add(customers[i].id);
        
        // Compare with remaining unprocessed customers
        for (let j = 0; j < customers.length; j++) {
          if (i === j || processed.has(customers[j].id)) continue;
          
          // Check for fuzzy name matching
          const firstName1 = customers[i].firstName?.toLowerCase().trim() || '';
          const firstName2 = customers[j].firstName?.toLowerCase().trim() || '';
          
          const lastName1 = customers[i].lastName?.toLowerCase().trim() || '';
          const lastName2 = customers[j].lastName?.toLowerCase().trim() || '';
          
          const firstNameSimilarity = calculateSimilarity(firstName1, firstName2);
          const lastNameSimilarity = calculateSimilarity(lastName1, lastName2);
          
          // Consider a match if both first and last name have good similarity
          let isMatch = false;
          let matchSimilarity = 0;
          
          if ((firstNameSimilarity > 0.85 && lastNameSimilarity > 0.75) || 
              (firstNameSimilarity > 0.75 && lastNameSimilarity > 0.85)) {
            isMatch = true;
            matchSimilarity = (firstNameSimilarity + lastNameSimilarity) / 2;
          }
          
          if (isMatch) {
            potentialGroup.push({ 
              customer: customers[j], 
              similarity: matchSimilarity, 
              reason: 'fuzzy_match' 
            });
            processed.add(customers[j].id);
          }
        }
        
        // Create a duplicate group if more than one customer is found
        if (potentialGroup.length > 1) {
          const totalConfidence = potentialGroup.reduce((sum, item) => sum + item.similarity, 0);
          const averageConfidence = totalConfidence / potentialGroup.length;
          const confidence = Math.round(averageConfidence * 100);
          
          groups.push({
            id: uuidv4(),
            name: `${potentialGroup[0].customer.firstName} ${potentialGroup[0].customer.lastName}`,
            records: potentialGroup.map(item => item.customer),
            confidence: Math.min(confidence, 85), // Cap fuzzy match confidence at 85%
            matchReason: 'Similar name information'
          });
        }
      }
      
      setDuplicateGroups(groups);
      return groups;
    } finally {
      setIsProcessing(false);
    }
  };
  
  return {
    findDuplicates,
    duplicateGroups,
    isProcessing,
    clearGroups: () => setDuplicateGroups([])
  };
}
