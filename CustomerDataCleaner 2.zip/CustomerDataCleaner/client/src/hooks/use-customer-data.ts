import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Customer, FileHistory } from "@/lib/types";

// Hook for accessing and managing customer data
export function useCustomerData() {
  const queryClient = useQueryClient();

  // Fetch all customers
  const customersQuery = useQuery<Customer[]>({
    queryKey: ["/api/customers"],
  });

  // Fetch file history
  const fileHistoryQuery = useQuery<FileHistory[]>({
    queryKey: ["/api/file-history"],
  });

  // Fetch a single customer by ID
  const useCustomer = (id: number | null) => {
    return useQuery<Customer>({
      queryKey: [`/api/customers/${id}`],
      enabled: !!id,
    });
  };

  // Fetch dashboard analytics
  const useAnalytics = () => {
    return useQuery({
      queryKey: ["/api/analytics"],
    });
  };

  // Find potential duplicates
  const findDuplicatesMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("GET", "/api/find-duplicates", undefined);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/customers"] });
    },
  });

  // Merge duplicates
  const mergeDuplicatesMutation = useMutation({
    mutationFn: async (data: { groupId: string; primaryId: number; recordIds: number[] }) => {
      const response = await apiRequest("POST", "/api/merge-duplicates", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/customers"] });
    },
  });

  // Upload CSV file
  const uploadFileMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("file", file);

      const response = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error(`Upload failed: ${response.statusText}`);
      }

      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/customers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/file-history"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics"] });
    },
  });

  return {
    customers: customersQuery.data || [],
    isLoadingCustomers: customersQuery.isLoading,
    fileHistory: fileHistoryQuery.data || [],
    isLoadingFileHistory: fileHistoryQuery.isLoading,
    useCustomer,
    useAnalytics,
    findDuplicates: findDuplicatesMutation.mutate,
    isFindingDuplicates: findDuplicatesMutation.isPending,
    mergeDuplicates: mergeDuplicatesMutation.mutate,
    isMergingDuplicates: mergeDuplicatesMutation.isPending,
    uploadFile: uploadFileMutation.mutate,
    isUploading: uploadFileMutation.isPending,
    refetchCustomers: () => queryClient.invalidateQueries({ queryKey: ["/api/customers"] }),
    refetchFileHistory: () => queryClient.invalidateQueries({ queryKey: ["/api/file-history"] }),
  };
}
