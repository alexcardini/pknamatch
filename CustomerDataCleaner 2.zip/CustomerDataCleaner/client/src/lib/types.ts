// Product interface
export interface Product {
  id: number;
  name: string;
  sku: string;
  description?: string;
  price: number;
  createdAt: Date;
}

// Order item interface
export interface OrderItem {
  name: string;
  quantity: number;
  unitPrice: number;
}

// Order interface
export interface Order {
  orderId: string;
  date: string;
  products: OrderItem[];
  totalAmount: number;
}

// Customer interface
export interface Customer {
  id: number;
  customerId: string;
  firstName: string;
  lastName: string;
  phone: string;
  address: string;
  zone?: string;
  isMerged: boolean;
  mergedFrom?: string[];
  orderHistory?: Order[];
  totalSpent?: number;
  lastOrderDate?: Date;
  emptyRecord?: boolean;
  status: "clean" | "merged" | "for_review" | "merged_into";
  createdAt: Date;
  [key: string]: any;
}

// File history interface
export interface FileHistory {
  id: number;
  filename: string;
  recordCount: number;
  duplicatesFound?: number;
  processedAt: Date;
}

// Duplicate group interface
export interface DuplicateGroup {
  id: string;
  name: string;
  records: Customer[];
  confidence: number;
  matchReason?: string;
}

// CSV processing status type
export type ProcessingStage = 
  | "validation" 
  | "fuzzyMatching" 
  | "recordMerging" 
  | "idAssignment" 
  | "databaseUpdate";

// Analytics data interface
export interface AnalyticsData {
  totalCustomers: number;
  duplicatesCount: number;
  recentFiles: FileHistory[];
}
