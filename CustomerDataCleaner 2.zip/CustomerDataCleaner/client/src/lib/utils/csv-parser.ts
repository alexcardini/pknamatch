export interface CSVParserOptions {
  delimiter?: string;
  skipHeader?: boolean;
  columns?: string[];
  transform?: (row: Record<string, string>) => Record<string, any>;
}

export class CSVParseError extends Error {
  line: number;
  
  constructor(message: string, line: number) {
    super(message);
    this.name = "CSVParseError";
    this.line = line;
  }
}

export function parseCSV(
  content: string,
  options: CSVParserOptions = {}
): Record<string, any>[] {
  const {
    delimiter = ",",
    skipHeader = false,
    columns: providedColumns,
    transform,
  } = options;

  const lines = content.split(/\r?\n/).filter(line => line.trim().length > 0);
  if (lines.length === 0) {
    return [];
  }

  let columns: string[];
  let startIndex = 0;

  if (providedColumns) {
    columns = providedColumns;
  } else if (skipHeader) {
    startIndex = 1;
    const headerLine = lines[0];
    columns = parseCSVLine(headerLine, delimiter);
  } else {
    const headerLine = lines[0];
    columns = parseCSVLine(headerLine, delimiter);
    startIndex = 1;
  }

  const result: Record<string, any>[] = [];

  for (let i = startIndex; i < lines.length; i++) {
    const line = lines[i];
    try {
      const values = parseCSVLine(line, delimiter);
      
      if (values.length === 0) continue;
      
      // If we have fewer values than columns, pad with empty strings
      while (values.length < columns.length) {
        values.push("");
      }
      
      // If we have more values than columns, only use the first columns.length values
      const rowObj: Record<string, string> = {};
      for (let j = 0; j < columns.length; j++) {
        rowObj[columns[j]] = values[j];
      }
      
      const transformedRow = transform ? transform(rowObj) : rowObj;
      result.push(transformedRow);
    } catch (error) {
      throw new CSVParseError(`Error parsing line ${i + 1}: ${error.message}`, i + 1);
    }
  }

  return result;
}

// Helper function to parse a CSV line, handling quoted values
function parseCSVLine(line: string, delimiter: string): string[] {
  const result: string[] = [];
  let currentValue = "";
  let inQuotes = false;
  
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    
    if (char === '"') {
      if (inQuotes && i + 1 < line.length && line[i + 1] === '"') {
        // Handle escaped quotes (two double quotes in a row)
        currentValue += '"';
        i++; // Skip the next quote
      } else {
        // Toggle quote state
        inQuotes = !inQuotes;
      }
    } else if (char === delimiter && !inQuotes) {
      // End of field
      result.push(currentValue);
      currentValue = "";
    } else {
      // Add to current value
      currentValue += char;
    }
  }
  
  // Add the last value
  result.push(currentValue);
  
  return result;
}
