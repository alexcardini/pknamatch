import stringSimilarity from "string-similarity";

// Configuration for fuzzy matching
export interface FuzzyMatchOptions {
  threshold?: number;
  caseSensitive?: boolean;
  ignoreAccents?: boolean;
  ignoreOrder?: boolean;
}

// Default options
const defaultOptions: FuzzyMatchOptions = {
  threshold: 0.6,
  caseSensitive: false,
  ignoreAccents: true,
  ignoreOrder: false
};

/**
 * Performs fuzzy matching between two strings
 * @param str1 First string to compare
 * @param str2 Second string to compare
 * @param options Fuzzy matching options
 * @returns Similarity score between 0 and 1
 */
export function fuzzyMatch(
  str1: string,
  str2: string,
  options: FuzzyMatchOptions = {}
): number {
  const opts = { ...defaultOptions, ...options };
  
  if (!str1 || !str2) return 0;
  
  let s1 = str1;
  let s2 = str2;
  
  // Apply case sensitivity
  if (!opts.caseSensitive) {
    s1 = s1.toLowerCase();
    s2 = s2.toLowerCase();
  }
  
  // Handle accents
  if (opts.ignoreAccents) {
    s1 = normalizeAccents(s1);
    s2 = normalizeAccents(s2);
  }
  
  // Handle word order
  if (opts.ignoreOrder) {
    s1 = s1.split(/\s+/).sort().join(' ');
    s2 = s2.split(/\s+/).sort().join(' ');
  }
  
  return stringSimilarity.compareTwoStrings(s1, s2);
}

/**
 * Get the best match for a string from an array of candidates
 * @param query The string to find matches for
 * @param candidates Array of candidate strings to match against
 * @param options Fuzzy matching options
 * @returns Best match and its score
 */
export function findBestMatch(
  query: string,
  candidates: string[],
  options: FuzzyMatchOptions = {}
): { target: string; score: number; index: number } {
  const opts = { ...defaultOptions, ...options };
  
  // No candidates, return empty result
  if (!candidates.length) {
    return { target: "", score: 0, index: -1 };
  }
  
  // Only one candidate, compare directly
  if (candidates.length === 1) {
    const score = fuzzyMatch(query, candidates[0], opts);
    return { target: candidates[0], score, index: 0 };
  }
  
  // Find the best match from candidates
  const result = stringSimilarity.findBestMatch(query, candidates);
  
  return result.bestMatch;
}

/**
 * Normalizes accented characters in a string
 */
function normalizeAccents(str: string): string {
  return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

/**
 * Group similar strings based on fuzzy matching
 * @param strings Array of strings to group
 * @param options Fuzzy matching options
 * @returns Array of groups, where each group is an array of similar strings
 */
export function groupSimilarStrings(
  strings: string[],
  options: FuzzyMatchOptions = {}
): string[][] {
  const opts = { ...defaultOptions, ...options };
  const groups: string[][] = [];
  const processed = new Set<number>();
  
  for (let i = 0; i < strings.length; i++) {
    if (processed.has(i)) continue;
    
    const currentGroup: string[] = [strings[i]];
    processed.add(i);
    
    for (let j = i + 1; j < strings.length; j++) {
      if (processed.has(j)) continue;
      
      const similarity = fuzzyMatch(strings[i], strings[j], opts);
      
      if (similarity >= (opts.threshold || 0.6)) {
        currentGroup.push(strings[j]);
        processed.add(j);
      }
    }
    
    if (currentGroup.length > 0) {
      groups.push(currentGroup);
    }
  }
  
  return groups;
}
